#include<stdio.h>
int main()
{
int i,j,k,n;
printf("enter the number");
scanf("%d",&n);
for(i=0;i<n;i++)
{
    for(k=n-1;k>1;k--)
        printf(" ");
        for(j=0;j<=1;j++)
            printf("* ");
        printf("\n");
}
printf("\n");
for(i=0;i<n;i++)
{
    for(k=0;k<1;k++)
        printf(" ");
    for(j=n-1;j>=i;j--)
        printf("* ");
    printf("\n");
}
for(i=0;i<n;i++)
{

    for(j=0;j<n;j++)
        if(i==0||i==n-1||j==0||j==n-1||i==j||i==n-1-j)
        printf(" * ");
    else
        printf(" . ");
    printf("\n");
}
return 0;
}
