#include<stdio.h>
void nth_largest(int*data,int n_th,int size)
{
    if(n_th<0||n_th>size){
      printf("\n Invalid Input [%d].!\n",n_th);
      return;
    }
    else{
int index=0,j=0,counter=1,status=0;
for(index;index<size;index++)
    {
counter=0;
for(j=0;j<size;j++)
{
    if(data[index]<data[j] )
    {
        counter++;
        }
      }
if(counter==n_th){
printf("  %d",data[index]);
status=1;
        break;
      }
    }
    if(status==0)
        {
      printf("\n Not found [%d] nth largest element ",n_th);
    }
    }
}
