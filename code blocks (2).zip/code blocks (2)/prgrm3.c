#include<stdio.h>
int main()
{
int arr[10],freqarr[10],i,j,size,count;
printf("enter the elements:");
scanf("%d",&size);
printf("enter %d elements:",size);
 for(i=0;i<size;i++)
 {
    scanf("%d",&arr[i]);
    freqarr[i]=-1;
 }
   for( i-0;i<size;i++)
   {
       count=1;
       for(j=i+1;j<size;j++)
       {
           if(arr[i]==arr[j])
           {
               count++;
               freqarr[j]=0;
           }
       }
       if(freqarr[i]!=0)
       {
           freqarr[i]=count;
       }

    }
    printf("\nfrequency of all the elements in the array:");
    for(i=0;i<size;i++)
    {
        if(freqarr[i]!=0)
        {
            printf("\n%d occurs %d times",arr[i],freqarr[i]);
        }
    }
    return 0;
   }
